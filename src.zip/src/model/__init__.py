from .newnet import New_Net
from .prototype import ProtoType
from .resnet import Resnet
